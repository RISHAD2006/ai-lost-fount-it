"""
Campus Found-It AI
Flask Backend — Clean Rebuild
Author: Rishad M, Govt Polytechnic College Palakkad
"""

import os
import re
from flask import Flask, request, jsonify, render_template, session, redirect, url_for
from flask_cors import CORS
from supabase import create_client

# ============================================================
# APP SETUP
# ============================================================
app = Flask(__name__, template_folder="templates", static_folder="static")
app.secret_key = os.environ.get("SECRET_KEY", "campus-found-it-secret-2025")
CORS(app, supports_credentials=True)

# ============================================================
# SUPABASE CONNECTION
# ============================================================
SUPABASE_URL = os.environ.get("SUPABASE_URL", "")
SUPABASE_KEY = os.environ.get("SUPABASE_KEY", "")
supabase = create_client(SUPABASE_URL, SUPABASE_KEY) if SUPABASE_URL and SUPABASE_KEY else None

# ============================================================
# ADMIN CREDENTIALS (set in Render environment variables)
# ============================================================
ADMIN_EMAIL    = os.environ.get("ADMIN_EMAIL",    "admin@college.com")
ADMIN_PASSWORD = os.environ.get("ADMIN_PASSWORD", "admin123")


# ============================================================
#  TEXT MATCHING HELPERS  (Simple AI — no heavy libraries)
# ============================================================

STOP_WORDS = {"a","an","the","is","it","in","on","at","of","and","or",
              "my","i","was","were","have","has","with","to","for","this",
              "that","was","been","be","are","had"}

def clean(text):
    """
    Step 1 — Normalize text:
    lowercase → remove special chars → remove extra spaces
    """
    if not text:
        return ""
    text = text.lower()
    text = re.sub(r"[^a-z0-9\s]", " ", text)   # keep only letters, numbers, spaces
    text = re.sub(r"\s+", " ", text).strip()     # remove extra spaces
    return text

def keywords(text):
    """
    Step 2 — Extract meaningful keywords
    (remove stop words like 'a', 'the', 'is')
    """
    words = set(clean(text).split())
    return words - STOP_WORDS

def keyword_score(text1, text2):
    """
    Step 3 — Keyword overlap score (0 to 1)
    How many keywords are common between text1 and text2?
    Example:
      text1 = "black school bag"  → keywords: {black, school, bag}
      text2 = "black bag"         → keywords: {black, bag}
      common = {black, bag} → 2 out of 3 → score = 0.67
    """
    k1 = keywords(text1)
    k2 = keywords(text2)
    if not k1 or not k2:
        return 0.0
    common = k1 & k2
    return len(common) / max(len(k1), len(k2))

def fuzzy_score(text1, text2):
    """
    Step 4 — Fuzzy character-level similarity (0 to 1)
    Compares cleaned strings character by character.
    Works even when words are slightly different.
    """
    a = clean(text1)
    b = clean(text2)
    if not a or not b:
        return 0.0
    # Count matching characters at same positions
    matches = sum(ca == cb for ca, cb in zip(a, b))
    return matches / max(len(a), len(b))

def total_text_score(title1, desc1, title2, desc2):
    """
    Step 5 — Combined text score (0 to 100)
    Combines:
      - keyword match on title        (weight: 40%)
      - keyword match on description  (weight: 30%)
      - fuzzy score on full text      (weight: 30%)
    """
    full1 = (title1 or "") + " " + (desc1 or "")
    full2 = (title2 or "") + " " + (desc2 or "")

    kw_title = keyword_score(title1 or "", title2 or "")   # title keywords
    kw_desc  = keyword_score(desc1  or "", desc2  or "")   # description keywords
    fz       = fuzzy_score(full1, full2)                   # overall fuzzy

    combined = (kw_title * 0.40) + (kw_desc * 0.30) + (fz * 0.30)
    return round(combined * 100, 1)


# ============================================================
# PAGE ROUTES
# ============================================================
@app.route("/")
def home():
    return render_template("index.html")

@app.route("/login")
def login_page():
    return render_template("login.html")

@app.route("/register")
def register_page():
    return render_template("register.html")

@app.route("/dashboard")
def dashboard_page():
    return render_template("dashboard.html")

@app.route("/admin")
def admin_page():
    if not session.get("is_admin"):
        return redirect("/admin-login")
    return render_template("admin.html", admin_email=ADMIN_EMAIL)

@app.route("/admin-login")
def admin_login_page():
    if session.get("is_admin"):
        return redirect("/admin")
    return render_template("admin_login.html")

@app.route("/admin-logout")
def admin_logout():
    session.clear()
    return redirect("/admin-login")


# ============================================================
# AUTH API — Register
# ============================================================
@app.route("/api/register", methods=["POST"])
def api_register():
    if not supabase:
        return jsonify({"error": "Supabase not configured"}), 500

    data     = request.get_json() or {}
    name     = data.get("name",     "").strip()
    email    = data.get("email",    "").strip().lower()
    password = data.get("password", "").strip()
    phone    = data.get("phone",    "").strip()

    if not name or not email or not password:
        return jsonify({"error": "Name, email and password are required"}), 400

    # Check if email already exists
    existing = supabase.table("users").select("id").eq("email", email).execute()
    if existing.data:
        return jsonify({"error": "Email already registered"}), 400

    # Save user (plain password — simple for diploma project)
    result = supabase.table("users").insert({
        "name":     name,
        "email":    email,
        "password": password,
        "phone":    phone
    }).execute()

    if result.data:
        return jsonify({"message": "Registered successfully! Please login."})
    return jsonify({"error": "Registration failed"}), 500


# ============================================================
# AUTH API — Login
# ============================================================
@app.route("/api/login", methods=["POST"])
def api_login():
    if not supabase:
        return jsonify({"error": "Supabase not configured"}), 500

    data     = request.get_json() or {}
    email    = data.get("email",    "").strip().lower()
    password = data.get("password", "").strip()

    result = supabase.table("users").select("*").eq("email", email).eq("password", password).execute()

    if not result.data:
        return jsonify({"error": "Wrong email or password"}), 401

    user = result.data[0]
    return jsonify({
        "message":  "Login successful",
        "user_id":  user["id"],
        "name":     user["name"],
        "email":    user["email"],
        "phone":    user.get("phone", "")
    })


# ============================================================
# ADMIN LOGIN API
# ============================================================
@app.route("/api/admin-login", methods=["POST"])
def api_admin_login():
    data     = request.get_json() or {}
    email    = data.get("email",    "").strip().lower()
    password = data.get("password", "").strip()

    if email == ADMIN_EMAIL.lower() and password == ADMIN_PASSWORD:
        session["is_admin"] = True
        return jsonify({"message": "Admin login success"})
    return jsonify({"error": "Wrong admin credentials"}), 401


# ============================================================
# UPLOAD ITEM API
# ============================================================
@app.route("/api/upload", methods=["POST"])
def api_upload():
    if not supabase:
        return jsonify({"error": "Supabase not configured"}), 500

    data        = request.get_json() or {}
    user_id     = data.get("user_id")
    title       = data.get("title",       "").strip()
    description = data.get("description", "").strip()
    status      = data.get("status",      "").strip().lower()   # "lost" or "found"
    image_url   = data.get("image_url",   "").strip()
    contact     = data.get("contact",     "").strip()

    # Validation
    if not title or not status or not user_id:
        return jsonify({"error": "Title, status and user_id are required"}), 400
    if status not in ["lost", "found"]:
        return jsonify({"error": "Status must be 'lost' or 'found'"}), 400

    # Save item to Supabase
    new_item = supabase.table("items").insert({
        "user_id":     user_id,
        "title":       title,
        "description": description,
        "status":      status,
        "image_url":   image_url,
        "contact":     contact,
        "matched":     False
    }).execute()

    if not new_item.data:
        return jsonify({"error": "Failed to save item"}), 500

    saved_item = new_item.data[0]

    # ── RUN MATCHING ──
    # Find opposite items (lost → search found, found → search lost)
    opposite = "found" if status == "lost" else "lost"
    candidates_result = supabase.table("items").select("*").eq("status", opposite).eq("matched", False).execute()
    candidates = candidates_result.data or []

    matches = []
    for candidate in candidates:
        score = total_text_score(
            title,       description,
            candidate.get("title", ""), candidate.get("description", "")
        )
        if score >= 30:   # Only include if score >= 30%
            matches.append({
                "id":          candidate["id"],
                "title":       candidate["title"],
                "description": candidate.get("description", ""),
                "image_url":   candidate.get("image_url", ""),
                "contact":     candidate.get("contact", ""),
                "status":      candidate["status"],
                "score":       score
            })

    # Sort by highest score first
    matches.sort(key=lambda x: x["score"], reverse=True)

    # If top match score is very high (≥ 70), mark both as matched
    if matches and matches[0]["score"] >= 70:
        best_id = matches[0]["id"]
        supabase.table("items").update({"matched": True}).eq("id", saved_item["id"]).execute()
        supabase.table("items").update({"matched": True}).eq("id", best_id).execute()

    return jsonify({
        "message": "Item uploaded successfully",
        "item":    saved_item,
        "matches": matches[:5]   # Return top 5 matches
    })


# ============================================================
# GET ALL ITEMS (for dashboard — all users see everything)
# ============================================================
@app.route("/api/items", methods=["GET"])
def api_get_items():
    if not supabase:
        return jsonify({"error": "Supabase not configured"}), 500

    status = request.args.get("status")   # optional filter: lost / found

    if status:
        result = supabase.table("items").select("*").eq("status", status).order("id", desc=True).execute()
    else:
        result = supabase.table("items").select("*").order("id", desc=True).execute()

    return jsonify(result.data or [])


# ============================================================
# GET MY ITEMS
# ============================================================
@app.route("/api/my-items/<int:user_id>", methods=["GET"])
def api_my_items(user_id):
    if not supabase:
        return jsonify({"error": "Supabase not configured"}), 500

    result = supabase.table("items").select("*").eq("user_id", user_id).order("id", desc=True).execute()
    return jsonify(result.data or [])


# ============================================================
# SEARCH ITEMS (text matching from search bar)
# ============================================================
@app.route("/api/search", methods=["GET"])
def api_search():
    if not supabase:
        return jsonify({"error": "Supabase not configured"}), 500

    query = request.args.get("q", "").strip()
    if not query:
        return jsonify([])

    all_items = supabase.table("items").select("*").execute().data or []

    results = []
    for item in all_items:
        score = total_text_score(query, "", item.get("title", ""), item.get("description", ""))
        if score >= 20:
            item["score"] = score
            results.append(item)

    results.sort(key=lambda x: x["score"], reverse=True)
    return jsonify(results[:20])


# ============================================================
# DELETE ITEM
# ============================================================
@app.route("/api/delete/<int:item_id>", methods=["DELETE"])
def api_delete(item_id):
    if not supabase:
        return jsonify({"error": "Supabase not configured"}), 500

    supabase.table("items").delete().eq("id", item_id).execute()
    return jsonify({"message": "Deleted"})


# ============================================================
# ADMIN API — All items with user contact
# ============================================================
@app.route("/api/admin/items", methods=["GET"])
def api_admin_items():
    if not session.get("is_admin"):
        return jsonify({"error": "Unauthorized"}), 401

    if not supabase:
        return jsonify({"error": "Supabase not configured"}), 500

    items = supabase.table("items").select("*").order("id", desc=True).execute().data or []
    return jsonify(items)


@app.route("/api/admin/users", methods=["GET"])
def api_admin_users():
    if not session.get("is_admin"):
        return jsonify({"error": "Unauthorized"}), 401

    if not supabase:
        return jsonify({"error": "Supabase not configured"}), 500

    users = supabase.table("users").select("id, name, email, phone").order("id", desc=True).execute().data or []
    return jsonify(users)


@app.route("/api/admin/delete/<int:item_id>", methods=["DELETE"])
def api_admin_delete(item_id):
    if not session.get("is_admin"):
        return jsonify({"error": "Unauthorized"}), 401

    if not supabase:
        return jsonify({"error": "Supabase not configured"}), 500

    supabase.table("items").delete().eq("id", item_id).execute()
    return jsonify({"message": "Deleted"})


@app.route("/api/admin/update/<int:item_id>", methods=["PATCH"])
def api_admin_update(item_id):
    if not session.get("is_admin"):
        return jsonify({"error": "Unauthorized"}), 401

    if not supabase:
        return jsonify({"error": "Supabase not configured"}), 500

    data = request.get_json() or {}
    supabase.table("items").update(data).eq("id", item_id).execute()
    return jsonify({"message": "Updated"})


# ============================================================
# RUN
# ============================================================
if __name__ == "__main__":
    port = int(os.environ.get("PORT", 5000))
    app.run(host="0.0.0.0", port=port, debug=False)
