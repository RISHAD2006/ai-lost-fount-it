/*
  Campus Found-It AI — script.js
  Global helpers. Each HTML page has its own logic inline.
*/

function logout() {
  localStorage.clear();
  window.location.href = "/login";
}

function esc(s) {
  const d = document.createElement("div");
  d.innerText = s || "";
  return d.innerHTML;
}
